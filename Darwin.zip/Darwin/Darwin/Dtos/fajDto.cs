﻿namespace Darwin.Dtos
{
    public class fajDto
    {
        public int Id { get; set; }
        public string? FajNev { get; set; }
        public string? OsztalyNev { get; set; }
        public string? AltorzsNev { get; set; }
        public string? TorzsNev { get; set; }
        public string? OrszagNev { get; set; }
        public byte[]? IndexKep { get; set; }
    }
}
