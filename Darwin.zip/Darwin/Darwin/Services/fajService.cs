﻿using Darwin.Dtos;
using Darwin.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Darwin.Services
{
    public class fajService
    {
        public static List<Faj> GetFajFull()
        {
            var context = new DarwinContext();
            try
            {
                var response = context.Fajs.Include(f=>f.Osztaly.AlTorzs.Torzs.Orszag).Include(f=>f.Osztaly.AlTorzs.Torzs).Include(f=>f.Osztaly.AlTorzs).Include(f=>f.Osztaly).Include(f=>f.Image).ToList();
                return response;
            }
            catch (Exception ex)
            {
                List<Faj> response = new List<Faj>();
                return response;
            }
        }

        public static List<fajDto> GetFajDto()
        {
            var context = new DarwinContext();
            try
            {

                var response = context.Fajs.Include(f => f.Osztaly.AlTorzs.Torzs.Orszag).Include(f => f.Osztaly.AlTorzs.Torzs).Include(f => f.Osztaly.AlTorzs).Include(f => f.Osztaly).Include(f => f.Image).Select(f=> new fajDto(){Id = f.Id, FajNev = f.Nev, OsztalyNev = f.Osztaly.Nev, AltorzsNev = f.Osztaly.AlTorzs.Nev, TorzsNev = f.Osztaly.AlTorzs.Torzs.Nev, OrszagNev = f.Osztaly.AlTorzs.Torzs.Orszag.Nev, IndexKep = f.Image.IndexImage }).ToList();
                return response;
            }
            catch (Exception ex)
            {
                List<fajDto> response = new List<fajDto>();
                return response;
            }
        }

    }
}
