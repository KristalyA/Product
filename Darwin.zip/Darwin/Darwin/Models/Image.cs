﻿using System;
using System.Collections.Generic;

namespace Darwin.Models;

public partial class Image
{
    public int Id { get; set; }

    public int FajId { get; set; }

    public byte[] IndexImage { get; set; } = null!;

    public byte[] Image1 { get; set; } = null!;

    public virtual Faj Faj { get; set; } = null!;
}
