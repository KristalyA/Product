﻿using System;
using System.Collections.Generic;

namespace Darwin.Models;

public partial class Altorz
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public int TorzsId { get; set; }

    public virtual ICollection<Osztaly> Osztalies { get; set; } = new List<Osztaly>();

    public virtual Torz Torzs { get; set; } = null!;
}
