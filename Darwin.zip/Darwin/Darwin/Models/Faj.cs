﻿using System;
using System.Collections.Generic;

namespace Darwin.Models;

public partial class Faj
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public int OsztalyId { get; set; }

    public virtual Image? Image { get; set; }

    public virtual Osztaly Osztaly { get; set; } = null!;
}
