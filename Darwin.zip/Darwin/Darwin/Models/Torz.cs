﻿using System;
using System.Collections.Generic;

namespace Darwin.Models;

public partial class Torz
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public int OrszagId { get; set; }

    public virtual ICollection<Altorz> Altorzs { get; set; } = new List<Altorz>();

    public virtual Orszag Orszag { get; set; } = null!;
}
