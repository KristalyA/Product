﻿using System;
using System.Collections.Generic;

namespace Darwin.Models;

public partial class Orszag
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public virtual ICollection<Torz> Torzs { get; set; } = new List<Torz>();
}
