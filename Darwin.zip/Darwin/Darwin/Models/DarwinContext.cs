﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Darwin.Models;

public partial class DarwinContext : DbContext
{
    public DarwinContext()
    {
    }

    public DarwinContext(DbContextOptions<DarwinContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Altorz> Altorzs { get; set; }

    public virtual DbSet<Faj> Fajs { get; set; }

    public virtual DbSet<Image> Images { get; set; }

    public virtual DbSet<Orszag> Orszags { get; set; }

    public virtual DbSet<Osztaly> Osztalies { get; set; }

    public virtual DbSet<Torz> Torzs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySQL("SERVER=localhost;PORT=3306;DATABASE=darwin;USER=root;PASSWORD=;SSL MODE=none;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Altorz>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("altorzs");

            entity.HasIndex(e => e.TorzsId, "TorzsId");

            entity.Property(e => e.Nev).HasMaxLength(64);

            entity.HasOne(d => d.Torzs).WithMany(p => p.Altorzs)
                .HasForeignKey(d => d.TorzsId)
                .HasConstraintName("altorzs_ibfk_1");
        });

        modelBuilder.Entity<Faj>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("faj");

            entity.HasIndex(e => e.OsztalyId, "OsztalyId");

            entity.Property(e => e.Nev).HasMaxLength(64);

            entity.HasOne(d => d.Osztaly).WithMany(p => p.Fajs)
                .HasForeignKey(d => d.OsztalyId)
                .HasConstraintName("faj_ibfk_1");
        });

        modelBuilder.Entity<Image>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("images");

            entity.HasIndex(e => e.FajId, "FajId").IsUnique();

            entity.Property(e => e.Image1)
                .HasColumnType("mediumblob")
                .HasColumnName("Image");
            entity.Property(e => e.IndexImage).HasColumnType("blob");

            entity.HasOne(d => d.Faj).WithOne(p => p.Image)
                .HasForeignKey<Image>(d => d.FajId)
                .HasConstraintName("images_ibfk_1");
        });

        modelBuilder.Entity<Orszag>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("orszag");

            entity.Property(e => e.Nev).HasMaxLength(64);
        });

        modelBuilder.Entity<Osztaly>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("osztaly");

            entity.HasIndex(e => e.AlTorzsId, "AlTorzsId");

            entity.Property(e => e.Nev).HasMaxLength(64);

            entity.HasOne(d => d.AlTorzs).WithMany(p => p.Osztalies)
                .HasForeignKey(d => d.AlTorzsId)
                .HasConstraintName("osztaly_ibfk_1");
        });

        modelBuilder.Entity<Torz>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("torzs");

            entity.HasIndex(e => e.OrszagId, "OrszagId");

            entity.Property(e => e.Nev).HasMaxLength(64);

            entity.HasOne(d => d.Orszag).WithMany(p => p.Torzs)
                .HasForeignKey(d => d.OrszagId)
                .HasConstraintName("torzs_ibfk_1");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
