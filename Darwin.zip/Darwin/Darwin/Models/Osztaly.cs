﻿using System;
using System.Collections.Generic;

namespace Darwin.Models;

public partial class Osztaly
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public int AlTorzsId { get; set; }

    public virtual Altorz AlTorzs { get; set; } = null!;

    public virtual ICollection<Faj> Fajs { get; set; } = new List<Faj>();
}
