﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Darwin.Services;


namespace Darwin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FajController : ControllerBase
    {
        [HttpGet]

        public Task<IActionResult> GET() 
        {
            var response; 
        }
    }
}
