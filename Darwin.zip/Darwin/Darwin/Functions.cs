﻿namespace Darwin
{
    public class Functions
    {
        public static string ImageOut(byte[] image)
        {
            string imgBaseData = Convert.ToBase64String(image);
            string imageURL = string.Format("data:image/jpg;base64,{0}", imgBaseData);
            return imageURL;
        }
    }
}
